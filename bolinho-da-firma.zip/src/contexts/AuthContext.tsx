import React, { createContext, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { doc, getDoc, setDoc, onSnapshot, updateDoc } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { UserProfile } from '../types';
import { handleFirestoreError, OperationType } from '../lib/error-handler';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType>({ user: null, profile: null, loading: true });

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setUser(user);
      if (user) {
        const userDocRef = doc(db, 'users', user.uid);
        
        // Listen for profile changes
        const unsubProfile = onSnapshot(userDocRef, (docSnap) => {
          if (docSnap.exists()) {
            const data = docSnap.data() as UserProfile;
            const isMasterEmail = user.email?.toLowerCase() === 'guirocks2016@gmail.com';
            
            // Force upgrade to 'master' if they are the master email
            if (isMasterEmail && data.role !== 'master') {
              updateDoc(userDocRef, { role: 'master' }).catch(err => {
                console.error('Failed to auto-upgrade to master:', err);
              });
              setProfile({ ...data, role: 'master' });
            } else {
              setProfile(data);
            }
          } else {
            // Create initial profile
            const isMasterEmail = user.email?.toLowerCase() === 'guirocks2016@gmail.com';
            const newProfile: UserProfile = {
              uid: user.uid,
              name: user.displayName || 'Usuário',
              email: user.email || '',
              photoUrl: user.photoURL || '',
              birthdayMonth: -1,
              birthdayDay: -1,
              role: isMasterEmail ? 'master' : 'user'
            };
            
            setDoc(userDocRef, newProfile).catch(err => {
              handleFirestoreError(err, OperationType.CREATE, `users/${user.uid}`);
            });
            setProfile(newProfile);
          }
          setLoading(false);
        }, (error) => {
          handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
          setLoading(false);
        });

        return () => unsubProfile();
      } else {
        setProfile(null);
        setLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  return (
    <AuthContext.Provider value={{ user, profile, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
