import React from 'react';
import { useAuth } from './contexts/AuthContext';
import { signInWithGoogle } from './lib/firebase';
import BirthdayCalendar from './components/BirthdayCalendar';
import PaymentSection from './components/PaymentSection';
import ProfileSection from './components/ProfileSection';
import ReportSection from './components/ReportSection';
import UserManagementSection from './components/UserManagementSection';
import FinancialStatementSection from './components/FinancialStatementSection';
import { Cake, LayoutDashboard, Wallet, UserCircle, PieChart, Users as UsersIcon, FileText, LucideIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type Tab = 'dashboard' | 'payments' | 'profile' | 'reports' | 'users' | 'extrato';

import ThemeToggle from './components/ThemeToggle';

export default function App() {
  const { user, profile, loading } = useAuth();
  const [activeTab, setActiveTab] = React.useState<Tab>('dashboard');

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-neutral-50 dark:bg-neutral-900">
        <div className="w-12 h-12 border-4 border-brand border-t-transparent animate-spin rounded-full" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f97316] dark:bg-neutral-950 overflow-hidden relative p-6 transition-colors duration-300">
        {/* Background blobs */}
        <div className="absolute top-0 left-0 w-96 h-96 bg-orange-400 dark:bg-orange-900/20 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-red-400 dark:bg-red-900/20 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse delay-700" />
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card max-w-md w-full p-8 text-center relative z-10"
        >
          <div className="flex justify-end absolute top-4 right-4">
            <ThemeToggle />
          </div>
          <div className="w-20 h-20 bg-brand rounded-3xl mx-auto flex items-center justify-center shadow-2xl shadow-brand/40 mb-6 rotate-3">
            <Cake className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-display font-bold text-neutral-800 dark:text-neutral-100 mb-2">Bolinho da Firma</h1>
          <p className="text-neutral-500 dark:text-neutral-400 mb-8 leading-relaxed">
            Organize os aniversários e contribuições mensais da sua equipe de forma simples e divertida.
          </p>
          <button 
            onClick={signInWithGoogle}
            className="w-full flex items-center justify-center gap-3 bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 py-4 px-6 rounded-2xl font-bold text-neutral-700 dark:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-700 transition-all shadow-sm active:scale-95"
          >
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-5 h-5" alt="Google" />
            Entrar com Google
          </button>
          <p className="mt-8 text-[10px] text-neutral-400 dark:text-neutral-500 uppercase tracking-widest font-bold">
            Feito para equipes produtivas
          </p>
        </motion.div>
      </div>
    );
  }

  const tabs: { id: Tab; icon: LucideIcon; label: string; adminOnly?: boolean }[] = [
    { id: 'dashboard', icon: LayoutDashboard, label: 'Início' },
    { id: 'payments', icon: Wallet, label: 'Pagamentos' },
    { id: 'profile', icon: UserCircle, label: 'Perfil' },
    { id: 'reports', icon: PieChart, label: 'Relatórios', adminOnly: true },
    { id: 'extrato', icon: FileText, label: 'Extrato' },
    { id: 'users', icon: UsersIcon, label: 'Usuários', adminOnly: true },
  ];

  const hasAdminAccess = profile?.role === 'admin' || profile?.role === 'master';

  return (
    <div className="min-h-screen bg-neutral-50 dark:bg-neutral-900 flex flex-col md:flex-row font-sans transition-colors duration-300">
      {/* Mobile Header */}
      <header className="md:hidden bg-white dark:bg-neutral-900 border-b border-neutral-100 dark:border-neutral-800 p-4 sticky top-0 z-50 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-brand rounded-lg flex items-center justify-center shadow-lg shadow-brand/20">
            <Cake className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-lg font-display font-bold text-neutral-800 dark:text-neutral-100">Bolinho</h1>
        </div>
        <div className="flex items-center gap-4">
          <ThemeToggle />
          <img 
            src={profile?.photoUrl || user?.photoURL || ''} 
            className="w-8 h-8 rounded-full border border-neutral-200 dark:border-neutral-700" 
            alt="Profile" 
            onClick={() => setActiveTab('profile')}
          />
        </div>
      </header>

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 bg-white dark:bg-neutral-800 border-r border-neutral-100 dark:border-neutral-800 p-6 sticky h-screen top-0 transition-colors duration-300">
        <div className="flex items-center justify-between mb-12 px-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-brand rounded-xl flex items-center justify-center shadow-xl shadow-brand/20 rotate-3">
              <Cake className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-xl font-display font-bold text-neutral-800 dark:text-neutral-100">Bolinho</h1>
          </div>
        </div>

        <nav className="space-y-1 flex-1">
          {tabs.map((tab) => {
            if (tab.adminOnly && !hasAdminAccess) return null;
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all group ${
                  isActive 
                    ? 'bg-brand/10 text-brand' 
                    : 'text-neutral-500 hover:bg-neutral-50 dark:hover:bg-neutral-700 hover:text-neutral-800 dark:hover:text-neutral-200'
                }`}
              >
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : 'group-hover:scale-110'}`} />
                {tab.label}
              </button>
            );
          })}
        </nav>

        <div className="mt-auto pt-6 border-t border-neutral-100 dark:border-neutral-700 space-y-6">
          <div className="px-2">
            <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider mb-3">Aparência</p>
            <ThemeToggle />
          </div>

          <div className="flex items-center gap-3 px-2">
            <img 
              src={profile?.photoUrl || user?.photoURL || ''} 
              className="w-10 h-10 rounded-full border border-neutral-200 dark:border-neutral-700" 
              alt="Profile" 
            />
            <div className="overflow-hidden">
              <p className="text-sm font-bold text-neutral-800 dark:text-neutral-100 truncate leading-tight">{profile?.name || user?.displayName}</p>
              <p className="text-[10px] text-neutral-500 dark:text-neutral-400 font-bold uppercase tracking-wider flex items-center gap-1">
                {profile?.role === 'master' ? (
                  <>
                    <span className="w-1 h-1 rounded-full bg-amber-500 animate-pulse" />
                    Master Admin
                  </>
                ) : profile?.role === 'admin' ? (
                  <>
                    <span className="w-1 h-1 rounded-full bg-brand animate-pulse" />
                    Administrador
                  </>
                ) : (
                  'Membro Premium'
                )}
              </p>
            </div>
          </div>
        </div>
      </aside>

      {/* Content Area */}
      <main className="flex-1 p-4 md:p-8 lg:p-12 overflow-y-auto">
        <div className="max-w-4xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === 'dashboard' && (
                <div className="space-y-8">
                  <div>
                    <h1 className="text-3xl font-display font-bold text-neutral-800 dark:text-neutral-100 mb-2">
                      Olá, {profile?.name.split(' ')[0]}! 👋
                    </h1>
                    <p className="text-neutral-500 dark:text-neutral-400">Veja quem sopra as velinhas este mês.</p>
                  </div>
                  <BirthdayCalendar />
                </div>
              )}
              {activeTab === 'payments' && (
                <div className="space-y-8">
                   <div>
                    <h1 className="text-3xl font-display font-bold text-neutral-800 dark:text-neutral-100 mb-2">Financeiro</h1>
                    <p className="text-neutral-500 dark:text-neutral-400">Envie seus comprovantes para garantir o bolo.</p>
                  </div>
                  <PaymentSection />
                </div>
              )}
              {activeTab === 'profile' && (
                <div className="space-y-8">
                   <div>
                    <h1 className="text-3xl font-display font-bold text-neutral-800 dark:text-neutral-100 mb-2">Seu Perfil</h1>
                    <p className="text-neutral-500 dark:text-neutral-400">Mantenha seus dados atualizados para não esquecermos do seu dia.</p>
                  </div>
                  <ProfileSection />
                </div>
              )}
              {activeTab === 'reports' && hasAdminAccess && (
                <div className="space-y-8">
                   <div>
                    <h1 className="text-3xl font-display font-bold text-neutral-800 dark:text-neutral-100 mb-2">Administração</h1>
                    <p className="text-neutral-500 dark:text-neutral-400">Visão geral das contribuições da equipe.</p>
                  </div>
                  <ReportSection />
                </div>
              )}
              {activeTab === 'users' && hasAdminAccess && (
                <div className="space-y-8">
                   <div>
                    <h1 className="text-3xl font-display font-bold text-neutral-800 dark:text-neutral-100 mb-2">Usuários</h1>
                    <p className="text-neutral-500 dark:text-neutral-400">Gerencie os membros da plataforma.</p>
                  </div>
                  <UserManagementSection />
                </div>
              )}
              {activeTab === 'extrato' && (
                <div className="space-y-8">
                   <div>
                    <h1 className="text-3xl font-display font-bold text-neutral-800 dark:text-neutral-100 mb-2">Extrato Financeiro</h1>
                    <p className="text-neutral-500 dark:text-neutral-400">Acompanhe a arrecadação e os gastos do mês.</p>
                  </div>
                  <FinancialStatementSection />
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Mobile Nav */}
      <nav className="md:hidden bg-white dark:bg-neutral-900 border-t border-neutral-100 dark:border-neutral-800 p-2 flex justify-around sticky bottom-0 z-50">
        {tabs.map((tab) => {
          if (tab.adminOnly && !hasAdminAccess) return null;
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-all ${
                isActive ? 'text-brand' : 'text-neutral-400 dark:text-neutral-500'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] font-bold uppercase tracking-wider">{tab.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
