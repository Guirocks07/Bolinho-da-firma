export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  photoUrl: string;
  birthdayMonth: number; // 0-11
  birthdayDay: number;
  cakeFlavor?: string;
  role: 'user' | 'admin' | 'master';
}

export interface Expense {
  id?: string;
  description: string;
  type: string;
  amount: number;
  date: string; // ISO date string
  month: number;
  year: number;
  createdBy: string; // admin uid
  timestamp: any;
}

export interface Contribution {
  id?: string;
  userId: string;
  userName: string;
  userPhoto?: string;
  month: number;
  year: number;
  receiptUrl?: string; // File URL
  status: 'pending' | 'approved' | 'rejected';
  amount: number;
  timestamp: any;
}
