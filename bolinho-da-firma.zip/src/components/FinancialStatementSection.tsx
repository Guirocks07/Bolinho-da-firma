import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, addDoc, serverTimestamp, orderBy, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { Contribution, Expense } from '../types';
import { Wallet, TrendingUp, TrendingDown, Plus, Trash2, Calendar, Tag, CreditCard, ChevronDown } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { handleFirestoreError, OperationType } from '../lib/error-handler';

export default function FinancialStatementSection() {
  const { profile } = useAuth();
  const isAdmin = profile?.role === 'admin' || profile?.role === 'master';
  
  const [contributions, setContributions] = useState<Contribution[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  
  const [isAddingExpense, setIsAddingExpense] = useState(false);
  const [loading, setLoading] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  
  // Expense Form State
  const [description, setDescription] = useState('');
  const [expenseType, setExpenseType] = useState('');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'));

  useEffect(() => {
    // Sub to approved contributions for the selected period
    const qContrib = query(
      collection(db, 'contributions'),
      where('month', '==', selectedMonth),
      where('year', '==', selectedYear),
      where('status', '==', 'approved')
    );

    const unsubscribeContrib = onSnapshot(qContrib, (snap) => {
      setContributions(snap.docs.map(d => ({ id: d.id, ...d.data() } as Contribution)));
    });

    // Sub to expenses for the selected period
    const qExpenses = query(
      collection(db, 'expenses'),
      where('month', '==', selectedMonth),
      where('year', '==', selectedYear),
      orderBy('date', 'desc')
    );

    const unsubscribeExpenses = onSnapshot(qExpenses, (snap) => {
      setExpenses(snap.docs.map(d => ({ id: d.id, ...d.data() } as Expense)));
    });

    return () => {
      unsubscribeContrib();
      unsubscribeExpenses();
    };
  }, [selectedMonth, selectedYear]);

  const totalCollected = contributions.reduce((acc, c) => acc + c.amount, 0);
  const totalSpent = expenses.reduce((acc, e) => acc + e.amount, 0);
  const balance = totalCollected - totalSpent;

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin || loading) return;

    const numAmount = parseFloat(amount.replace(',', '.'));
    if (isNaN(numAmount) || numAmount <= 0) {
      alert('Por favor, insira um valor válido.');
      return;
    }

    setLoading(true);
    try {
      const expenseDate = new Date(date + 'T12:00:00'); // Use mid-day to avoid TZ issues
      
      await addDoc(collection(db, 'expenses'), {
        description,
        type: expenseType,
        amount: numAmount,
        date,
        month: expenseDate.getMonth(),
        year: expenseDate.getFullYear(),
        createdBy: profile.uid,
        timestamp: serverTimestamp()
      });

      setDescription('');
      setAmount('');
      setExpenseType('');
      setIsAddingExpense(false);
      alert('Despesa registrada com sucesso!');
    } catch (error) {
      console.error('Erro ao salvar despesa:', error);
      handleFirestoreError(error, OperationType.CREATE, 'expenses');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteExpense = async (id: string, description: string) => {
    if (deletingId) return;
    
    setDeletingId(id);
    try {
      await deleteDoc(doc(db, 'expenses', id));
      // Silent success as requested
    } catch (error: any) {
      console.error('Erro ao excluir despesa:', error);
      const errorMsg = error?.message || String(error);
      alert(`Erro técnico ao excluir: ${errorMsg}`);
      handleFirestoreError(error, OperationType.DELETE, `expenses/${id}`);
    } finally {
      setDeletingId(null);
    }
  };

  const months = Array.from({ length: 12 }, (_, i) => ({
    value: i,
    label: format(new Date(2000, i, 1), 'MMMM', { locale: ptBR })
  }));

  return (
    <div className="space-y-6">
      {/* Header & Filter */}
      <div className="bg-white dark:bg-neutral-800 p-6 rounded-3xl border border-neutral-100 dark:border-neutral-700 shadow-sm transition-colors duration-300">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-brand/10 text-brand flex items-center justify-center">
              <CreditCard className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-display font-bold text-neutral-800 dark:text-neutral-100">Extrato Financeiro</h2>
              <p className="text-xs text-neutral-400 dark:text-neutral-500 font-bold uppercase tracking-wider">Transparência total dos gastos</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <select 
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
              className="bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl px-4 py-2 text-sm dark:text-neutral-200 font-bold focus:outline-none appearance-none pr-10 relative"
            >
              {months.map(m => <option key={m.value} value={m.value} className="dark:bg-neutral-900">{m.label}</option>)}
            </select>
            <select 
              value={selectedYear}
              onChange={(e) => setSelectedYear(parseInt(e.target.value))}
              className="bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl px-4 py-2 text-sm dark:text-neutral-200 font-bold focus:outline-none appearance-none pr-10 relative"
            >
              {[2025, 2026, 2027].map(y => <option key={y} value={y} className="dark:bg-neutral-900">{y}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-neutral-800 p-6 rounded-3xl border border-neutral-100 dark:border-neutral-700 shadow-sm transition-colors duration-300">
          <div className="w-8 h-8 rounded-lg bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-500 flex items-center justify-center mb-4">
            <TrendingUp className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">Total Arrecadado</p>
          <p className="text-2xl font-display font-bold text-neutral-800 dark:text-neutral-100">R$ {totalCollected.toFixed(2).replace('.', ',')}</p>
        </div>
        
        <div className="bg-white dark:bg-neutral-800 p-6 rounded-3xl border border-neutral-100 dark:border-neutral-700 shadow-sm transition-colors duration-300">
          <div className="w-8 h-8 rounded-lg bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-500 flex items-center justify-center mb-4">
            <TrendingDown className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">Total em Despesas</p>
          <p className="text-2xl font-display font-bold text-neutral-800 dark:text-neutral-100 text-red-500 dark:text-red-400">R$ {totalSpent.toFixed(2).replace('.', ',')}</p>
        </div>

        <div className="bg-brand text-white p-6 rounded-3xl shadow-lg shadow-brand/20">
          <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center mb-4">
            <Wallet className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-white/70 uppercase tracking-wider">Saldo Restante</p>
          <p className="text-2xl font-display font-bold">R$ {balance.toFixed(2).replace('.', ',')}</p>
        </div>
      </div>

      {/* Action Button (Admin Only) */}
      {isAdmin && (
        <button 
          onClick={() => setIsAddingExpense(!isAddingExpense)}
          className="w-full bg-white dark:bg-neutral-800 border-2 border-dashed border-neutral-200 dark:border-neutral-700 p-4 rounded-2xl text-neutral-500 dark:text-neutral-400 font-bold hover:border-brand/40 hover:text-brand transition-all flex items-center justify-center gap-2"
        >
          {isAddingExpense ? <ChevronDown className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
          {isAddingExpense ? 'Fechar Formulário' : 'Lançar Nova Despesa'}
        </button>
      )}

      {/* Expense Form */}
      {isAdmin && isAddingExpense && (
        <div className="bg-white dark:bg-neutral-800 p-6 rounded-3xl border border-neutral-100 dark:border-neutral-700 shadow-sm transition-colors duration-300 animate-in slide-in-from-top-4 duration-300">
          <form onSubmit={handleAddExpense} className="space-y-4 font-sans">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase">Data da Despesa</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400 dark:text-neutral-500" />
                  <input 
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl text-sm dark:text-neutral-200 focus:outline-none focus:ring-2 focus:ring-brand/20"
                  />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase">Tipo de Despesa</label>
                <div className="relative">
                  <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400 dark:text-neutral-500" />
                  <input 
                    type="text"
                    required
                    placeholder="Ex: Bolo, Salgadinhos, Decoração..."
                    value={expenseType}
                    onChange={(e) => setExpenseType(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl text-sm dark:text-neutral-200 focus:outline-none focus:ring-2 focus:ring-brand/20"
                  />
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase">Descrição Detalhada</label>
                <input 
                  type="text"
                  required
                  placeholder="Ex: Compra do bolo Ferrero na padaria..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-4 py-3 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl text-sm dark:text-neutral-200 focus:outline-none focus:ring-2 focus:ring-brand/20"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase">Valor (R$)</label>
                <input 
                  type="text"
                  required
                  placeholder="0,00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-4 py-3 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl text-sm dark:text-neutral-200 font-bold focus:outline-none focus:ring-2 focus:ring-brand/20"
                />
              </div>
            </div>

            <button 
              type="submit"
              disabled={loading}
              className="w-full bg-brand text-white font-bold py-3 rounded-xl shadow-lg shadow-brand/20 hover:brightness-110 transition-all flex items-center justify-center gap-2"
            >
              {loading ? <div className="w-4 h-4 border-2 border-white border-t-transparent animate-spin rounded-full" /> : <Plus className="w-5 h-5" />}
              Lançar Despesa
            </button>
          </form>
        </div>
      )}

      {/* Expenses List */}
      <div className="bg-white dark:bg-neutral-800 rounded-3xl shadow-sm border border-neutral-100 dark:border-neutral-700 overflow-hidden transition-colors duration-300">
        <div className="p-6 border-b border-neutral-50 dark:border-neutral-700">
          <h3 className="font-display font-bold text-neutral-800 dark:text-neutral-100">Lançamentos do Mês</h3>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-neutral-50 dark:bg-neutral-900/50">
                <th className="px-6 py-4 text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">Data</th>
                <th className="px-6 py-4 text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">Tipo</th>
                <th className="px-6 py-4 text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">Descrição</th>
                <th className="px-6 py-4 text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">Valor</th>
                {isAdmin && <th className="px-6 py-4 text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider text-right">Ações</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-50 dark:divide-neutral-700 font-sans">
              {expenses.length === 0 ? (
                <tr>
                  <td colSpan={isAdmin ? 5 : 4} className="px-6 py-12 text-center text-neutral-400 dark:text-neutral-600 italic">
                    Nenhuma despesa lançada para este período.
                  </td>
                </tr>
              ) : (
                expenses.map(e => (
                  <tr key={e.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-900/50 transition-colors">
                    <td className="px-6 py-4 text-sm text-neutral-600 dark:text-neutral-400">
                      {format(new Date(e.date + 'T12:00:00'), 'dd/MM/yyyy')}
                    </td>
                    <td className="px-6 py-4">
                      <span className="px-2 py-1 bg-neutral-100 dark:bg-neutral-700 text-neutral-600 dark:text-neutral-400 rounded-lg text-[10px] font-bold uppercase">
                        {e.type}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm font-medium text-neutral-800 dark:text-neutral-200">
                      {e.description}
                    </td>
                    <td className="px-6 py-4 text-sm font-bold text-red-500 dark:text-red-400">
                      - R$ {e.amount.toFixed(2).replace('.', ',')}
                    </td>
                    {isAdmin && (
                      <td className="px-6 py-4 text-right">
                        <button 
                          onClick={() => handleDeleteExpense(e.id!, e.description)}
                          disabled={deletingId !== null}
                          className={`p-2 rounded-lg transition-all ${
                            deletingId === e.id 
                              ? 'text-neutral-300 dark:text-neutral-700' 
                              : 'text-neutral-400 hover:text-red-500 hover:bg-neutral-100 dark:hover:bg-red-900/40'
                          }`}
                          title="Excluir lançamento"
                        >
                          {deletingId === e.id ? (
                            <div className="w-4 h-4 border-2 border-neutral-300 border-t-transparent animate-spin rounded-full" />
                          ) : (
                            <Trash2 className="w-4 h-4" />
                          )}
                        </button>
                      </td>
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
