import React, { useState, useEffect } from 'react';
import { 
  format, 
  startOfMonth, 
  endOfMonth, 
  eachDayOfInterval, 
  isSameDay, 
  addMonths, 
  subMonths,
  getDay
} from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { ChevronLeft, ChevronRight, Cake } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { UserProfile } from '../types';
import { handleFirestoreError, OperationType } from '../lib/error-handler';

export default function BirthdayCalendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [birthdays, setBirthdays] = useState<UserProfile[]>([]);
  
  useEffect(() => {
    // Current month is 0-11
    const currentMonth = currentDate.getMonth();
    const q = query(collection(db, 'users'), where('birthdayMonth', '==', currentMonth));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => doc.data() as UserProfile);
      setBirthdays(data);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'users');
    });
    
    return () => unsubscribe();
  }, [currentDate]);

  const daysInMonth = eachDayOfInterval({
    start: startOfMonth(currentDate),
    end: endOfMonth(currentDate)
  });

  const firstDayOfMonth = getDay(startOfMonth(currentDate));

  const nextMonth = () => setCurrentDate(addMonths(currentDate, 1));
  const prevMonth = () => setCurrentDate(subMonths(currentDate, 1));

  return (
    <div className="w-full bg-white dark:bg-neutral-800 rounded-3xl shadow-sm border border-neutral-100 dark:border-neutral-700 p-6 transition-colors duration-300">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-display font-bold text-neutral-800 dark:text-neutral-100 capitalize">
            {format(currentDate, 'MMMM yyyy', { locale: ptBR })}
          </h2>
          <p className="text-neutral-500 dark:text-neutral-400 text-sm">Aniversariantes do Mês</p>
        </div>
        <div className="flex gap-2">
          <button onClick={prevMonth} className="p-2 hover:bg-neutral-100 dark:hover:bg-neutral-700 rounded-xl transition-colors text-neutral-600 dark:text-neutral-400">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button onClick={nextMonth} className="p-2 hover:bg-neutral-100 dark:hover:bg-neutral-700 rounded-xl transition-colors text-neutral-600 dark:text-neutral-400">
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-2 mb-2">
        {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map(day => (
          <div key={day} className="text-center text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider py-2">
            {day}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-1 md:gap-2">
        {Array.from({ length: firstDayOfMonth }).map((_, i) => (
          <div key={`empty-${i}`} className="aspect-square" />
        ))}
        {daysInMonth.map((day, i) => {
          const birthdayPeople = birthdays.filter(b => b.birthdayDay === day.getDate());
          const isToday = isSameDay(day, new Date());
          
          return (
            <div 
              key={i} 
              className={`aspect-square relative rounded-lg md:rounded-2xl border flex flex-col items-center justify-center transition-all group hover:border-brand ${
                isToday ? 'bg-brand/5 border-brand/20 dark:bg-brand/10' : 'border-neutral-100 dark:border-neutral-700'
              }`}
            >
              <span className={`text-[10px] md:text-sm font-medium ${isToday ? 'text-brand font-bold' : 'text-neutral-600 dark:text-neutral-400'}`}>
                {day.getDate()}
              </span>
              
              <div className="flex -space-x-1 md:-space-x-2 mt-0.5 md:mt-1">
                {birthdayPeople.map((person, idx) => (
                  <motion.div
                    key={person.uid}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="relative"
                  >
                    <img 
                      src={person.photoUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${person.name}`}
                      alt={person.name}
                      className="w-3 h-3 md:w-6 md:h-6 rounded-full border border-white dark:border-neutral-800 object-cover"
                      title={person.name}
                    />
                    {idx === 0 && (
                      <Cake className="w-1.5 h-1.5 md:w-2.5 md:h-2.5 text-brand absolute -top-1 -right-1 bg-white dark:bg-neutral-800 rounded-full shadow-sm" />
                    )}
                  </motion.div>
                ))}
              </div>

              {birthdayPeople.length > 0 && (
                <div className="absolute inset-0 z-10 opacity-0 group-hover:opacity-100 pointer-events-none">
                   <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 bg-neutral-900 border border-neutral-800 text-white text-xs rounded-lg p-2 shadow-xl whitespace-pre">
                      {birthdayPeople.map(p => `${p.name}${p.cakeFlavor ? ` (${p.cakeFlavor})` : ''}`).join('\n')}
                   </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
      
      <div className="mt-8">
        <h3 className="text-sm font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-4">Lista de Aniversariantes</h3>
        <div className="flex flex-wrap gap-4">
          {birthdays.length === 0 ? (
            <p className="text-neutral-400 dark:text-neutral-600 text-sm italic">Nenhum aniversariante este mês.</p>
          ) : (
            birthdays.sort((a,b) => a.birthdayDay - b.birthdayDay).map(person => (
              <div key={person.uid} className="flex items-center gap-3 bg-neutral-50 dark:bg-neutral-900/50 px-4 py-2 rounded-2xl border border-neutral-100 dark:border-neutral-700">
                <img 
                  src={person.photoUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${person.name}`}
                  alt={person.name}
                  className="w-10 h-10 rounded-full border border-neutral-200 dark:border-neutral-700"
                />
                <div>
                  <p className="text-sm font-bold text-neutral-800 dark:text-neutral-100">{person.name}</p>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400">Dia {person.birthdayDay} • {person.cakeFlavor || 'Bolo a definir'}</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
