import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, addDoc, serverTimestamp, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { Contribution } from '../types';
import { handleFirestoreError, OperationType } from '../lib/error-handler';
import { CheckCircle2, Clock, XCircle, Coins, History, Send } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function PaymentSection() {
  const { profile } = useAuth();
  const [contributions, setContributions] = useState<Contribution[]>([]);
  const [loading, setLoading] = useState(false);
  const [amount, setAmount] = useState<string>('15.00');
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  useEffect(() => {
    if (!profile) return;
    
    const q = query(collection(db, 'contributions'), where('userId', '==', profile.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }) as Contribution);
      setContributions(data.sort((a, b) => (b.timestamp?.seconds || 0) - (a.timestamp?.seconds || 0)));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'contributions');
    });
    return () => unsubscribe();
  }, [profile]);

  const handleSubmit = async () => {
    if (!profile) return;

    const numAmount = parseFloat(amount.replace(',', '.'));
    if (isNaN(numAmount) || numAmount < 15) {
      alert('O valor mínimo para contribuição é R$ 15,00');
      return;
    }
    
    setLoading(true);
    console.log('Iniciando registro de contribuição...', {
      uid: profile.uid,
      month: selectedMonth,
      year: selectedYear,
      amount: numAmount
    });
    
    try {
      // 1. Verificações iniciais
      const existsQuery = query(
        collection(db, 'contributions'), 
        where('userId', '==', profile.uid),
        where('month', '==', selectedMonth),
        where('year', '==', selectedYear)
      );
      
      console.log('Verificando contribuição existente...');
      const existsSnap = await getDocs(existsQuery);
      
      if (!existsSnap.empty) {
        alert('Você já registrou uma contribuição para este mês!');
        return;
      }

      // 2. Salvar no Firestore
      console.log('Salvando dados no Firestore...');
      const docData = {
        userId: profile.uid,
        userName: profile.name,
        userPhoto: profile.photoUrl,
        month: selectedMonth,
        year: selectedYear,
        receiptUrl: null,
        status: 'pending',
        amount: numAmount,
        timestamp: serverTimestamp()
      };

      await addDoc(collection(db, 'contributions'), docData);
      
      console.log('Registro concluído com sucesso!');
      alert('Sua contribuição foi registrada e enviada para aprovação!');
    } catch (error: any) {
      console.error('Erro completo no registro:', error);
      
      let message = 'Erro ao registrar contribuição';
      if (error.code?.startsWith('firestore/') || error.message?.includes('permission-denied')) {
        message = 'Sem permissão no banco de dados (Firestore).';
        handleFirestoreError(error, OperationType.WRITE, 'contributions');
      }

      const displayError = typeof error.message === 'string' ? error.message : JSON.stringify(error);
      alert(`${message}. Detalhes técnicos: ${displayError}`);
    } finally {
      setLoading(false);
    }
  };

  const months = Array.from({ length: 12 }, (_, i) => ({
    value: i,
    label: format(new Date(2024, i, 1), 'MMMM', { locale: ptBR })
  }));

  const currentContribution = contributions.find(c => c.month === selectedMonth && c.year === selectedYear);

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-neutral-800 rounded-3xl shadow-sm border border-neutral-100 dark:border-neutral-700 p-6 transition-colors duration-300">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center text-brand">
            <Coins className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-display font-bold text-neutral-800 dark:text-neutral-100">Sua Contribuição</h2>
            <p className="text-sm text-neutral-500 dark:text-neutral-400 text-balance uppercase tracking-wider text-xs font-bold">Valor mínimo: R$ 15,00</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="space-y-1">
            <label className="text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">Valor (R$)</label>
            <input 
              type="text"
              inputMode="decimal"
              value={amount}
              onChange={(e) => {
                const val = e.target.value.replace(',', '.');
                if (/^\d*\.?\d{0,2}$/.test(val) || val === '') {
                  setAmount(e.target.value);
                }
              }}
              onBlur={() => {
                const num = parseFloat(amount.replace(',', '.'));
                if (!isNaN(num)) {
                  setAmount(num.toFixed(2));
                } else {
                  setAmount('15.00');
                }
              }}
              disabled={!!currentContribution}
              className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl px-4 py-3 text-base dark:text-white focus:outline-none focus:ring-2 focus:ring-brand/20 disabled:opacity-50 font-bold"
              placeholder="15.00"
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">Mês</label>
            <select 
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
              className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl px-4 py-3 text-base dark:text-white focus:outline-none focus:ring-2 focus:ring-brand/20"
            >
              {months.map(m => <option key={m.value} value={m.value} className="dark:bg-neutral-900">{m.label}</option>)}
            </select>
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">Ano</label>
            <select 
              value={selectedYear}
              onChange={(e) => setSelectedYear(parseInt(e.target.value))}
              className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl px-4 py-3 text-base dark:text-white focus:outline-none focus:ring-2 focus:ring-brand/20"
            >
              {[2025, 2026, 2027].map(y => <option key={y} value={y} className="dark:bg-neutral-900">{y}</option>)}
            </select>
          </div>
        </div>

        {currentContribution ? (
          <div className={`p-5 rounded-2xl flex items-center justify-between ${
            currentContribution.status === 'approved' ? 'bg-green-50 dark:bg-green-900/10 border border-green-100 dark:border-green-800' :
            currentContribution.status === 'rejected' ? 'bg-red-50 dark:bg-red-900/10 border border-red-100 dark:border-red-800' :
            'bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-800'
          }`}>
            <div className="flex items-center gap-4">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                currentContribution.status === 'approved' ? 'bg-green-100 dark:bg-green-900/20 text-green-600 dark:text-green-500' :
                currentContribution.status === 'rejected' ? 'bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-500' :
                'bg-amber-100 dark:bg-amber-900/20 text-amber-600 dark:text-amber-500'
              }`}>
                {currentContribution.status === 'approved' ? <CheckCircle2 className="w-6 h-6" /> :
                 currentContribution.status === 'rejected' ? <XCircle className="w-6 h-6" /> :
                 <Clock className="w-6 h-6" />}
              </div>
              <div>
                <p className="text-sm font-bold text-neutral-800 dark:text-neutral-100">
                  {currentContribution.status === 'approved' ? 'Contribuição Confirmada' :
                   currentContribution.status === 'rejected' ? 'Contribuição Recusada' : 'Aguardando Aprovação'}
                </p>
                <p className="text-xs text-neutral-500 dark:text-neutral-400">
                  {currentContribution.status === 'pending' 
                    ? 'O administrador irá validar seu registro em breve.'
                    : `Processado em ${format(currentContribution.timestamp?.toDate() || new Date(), 'dd/MM/yyyy')}`
                  }
                </p>
              </div>
            </div>
          </div>
        ) : (
          <button
            onClick={handleSubmit}
            disabled={loading}
            className="w-full bg-brand text-white font-bold py-4 rounded-2xl shadow-lg shadow-brand/20 hover:brightness-110 active:scale-[0.98] transition-all disabled:opacity-50 disabled:pointer-events-none flex items-center justify-center gap-3"
          >
            {loading ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent animate-spin rounded-full" />
                Registrando...
              </>
            ) : (
              <>
                <Send className="w-5 h-5" />
                Registrar Contribuição
              </>
            )}
          </button>
        )}
      </div>

      <div className="bg-white dark:bg-neutral-800 rounded-3xl shadow-sm border border-neutral-100 dark:border-neutral-700 p-6 transition-colors duration-300">
        <div className="flex items-center gap-2 mb-4">
          <History className="w-4 h-4 text-neutral-400 dark:text-neutral-500" />
          <h3 className="text-sm font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">Histórico Recente</h3>
        </div>
        <div className="space-y-3">
          {contributions.length === 0 ? (
            <p className="text-xs text-neutral-400 dark:text-neutral-600 italic">Nenhum pagamento registrado ainda.</p>
          ) : (
            contributions.slice(0, 5).map(c => (
              <div key={c.id} className="flex items-center justify-between p-3 rounded-xl hover:bg-neutral-50 dark:hover:bg-neutral-700 transition-colors bg-neutral-50/50 dark:bg-neutral-900/50 border border-transparent hover:border-neutral-100 dark:hover:border-neutral-600">
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    c.status === 'approved' ? 'bg-green-100 dark:bg-green-900/20 text-green-600 dark:text-green-500' :
                    c.status === 'rejected' ? 'bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-500' : 
                    'bg-amber-100 dark:bg-amber-900/20 text-amber-600 dark:text-amber-500'
                  }`}>
                    {c.status === 'approved' ? <CheckCircle2 className="w-4 h-4" /> :
                     c.status === 'rejected' ? <XCircle className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-neutral-800 dark:text-neutral-200 capitalize">
                      {months[c.month].label} {c.year}
                    </p>
                    <p className="text-[10px] text-neutral-400 dark:text-neutral-500 font-bold uppercase">R$ {c.amount.toFixed(2)}</p>
                  </div>
                </div>
                <div className={`text-[10px] font-bold px-2 py-1 rounded-full uppercase ${
                  c.status === 'approved' ? 'bg-green-50 dark:bg-green-900/20 text-green-600' :
                  c.status === 'rejected' ? 'bg-red-50 dark:bg-red-900/20 text-red-600' : 
                  'bg-amber-50 dark:bg-amber-900/20 text-amber-600'
                }`}>
                  {c.status === 'approved' ? 'OK' : c.status === 'rejected' ? 'X' : '...'}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
