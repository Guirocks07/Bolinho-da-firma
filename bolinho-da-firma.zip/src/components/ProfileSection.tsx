import React, { useState } from 'react';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { User, Calendar as CalendarIcon, Cake, Save, LogOut } from 'lucide-react';
import { logout } from '../lib/firebase';
import { handleFirestoreError, OperationType } from '../lib/error-handler';

export default function ProfileSection() {
  const { profile } = useAuth();
  const [name, setName] = useState(profile?.name || '');
  const [day, setDay] = useState(profile?.birthdayDay || 1);
  const [month, setMonth] = useState(profile?.birthdayMonth || 0);
  const [cakeFlavor, setCakeFlavor] = useState(profile?.cakeFlavor || '');
  const [saving, setSaving] = useState(false);

  if (!profile) return null;

  const handleSave = async () => {
    setSaving(true);
    try {
      const userRef = doc(db, 'users', profile.uid);
      await updateDoc(userRef, {
        name,
        birthdayDay: parseInt(day.toString()),
        birthdayMonth: parseInt(month.toString()),
        cakeFlavor
      }).catch(err => {
        handleFirestoreError(err, OperationType.UPDATE, `users/${profile.uid}`);
        throw err;
      });
      alert('Perfil atualizado!');
    } catch (error) {
      console.error(error);
      if (!(error instanceof Error && error.message.startsWith('{"error"'))) {
        alert('Erro ao salvar perfil');
      }
    } finally {
      setSaving(false);
    }
  };

  const isBirthdayMonth = profile.birthdayMonth === new Date().getMonth();

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-neutral-800 rounded-3xl shadow-sm border border-neutral-100 dark:border-neutral-700 p-6 transition-colors duration-300">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <div className="relative group">
              <img 
                src={profile.photoUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile.name}`}
                alt={profile.name}
                className="w-20 h-20 rounded-full border-4 border-white dark:border-neutral-800 shadow-md object-cover"
              />
            </div>
            <div>
              <h2 className="text-xl font-display font-bold text-neutral-800 dark:text-neutral-100">{profile.name}</h2>
              <div className="flex items-center gap-2">
                <p className="text-sm text-neutral-500 dark:text-neutral-400">{profile.email}</p>
                {profile.role === 'master' ? (
                  <span className="text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded-md bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-500 border border-amber-200 dark:border-amber-800">Master Admin</span>
                ) : profile.role === 'admin' ? (
                  <span className="text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded-md bg-brand/10 text-brand border border-brand/20 dark:border-brand/30">Administrador</span>
                ) : (
                  <span className="text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded-md bg-neutral-100 dark:bg-neutral-700 text-neutral-500 dark:text-neutral-400 border border-neutral-200 dark:border-neutral-600">Membro</span>
                )}
              </div>
            </div>
          </div>
          <button 
            onClick={() => logout()}
            className="p-2 text-neutral-400 hover:text-red-500 hover:bg-neutral-100 dark:hover:bg-neutral-700 rounded-xl transition-all"
            title="Sair"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider flex items-center gap-2">
              <User className="w-3 h-3" /> Nome Completo
            </label>
            <input 
              type="text" 
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl px-4 py-2.5 text-sm dark:text-neutral-200 focus:outline-none focus:ring-2 focus:ring-brand/20 transition-all font-medium"
              placeholder="Como você quer ser chamado?"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider flex items-center gap-2">
                <CalendarIcon className="w-3 h-3" /> Dia
              </label>
              <select 
                value={day}
                onChange={(e) => setDay(parseInt(e.target.value))}
                className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl px-4 py-2.5 text-sm dark:text-neutral-200 focus:outline-none focus:ring-2 focus:ring-brand/20"
              >
                {Array.from({ length: 31 }, (_, i) => i + 1).map(d => <option key={d} value={d} className="dark:bg-neutral-900">{d}</option>)}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider flex items-center gap-2">
                Mês
              </label>
              <select 
                value={month}
                onChange={(e) => setMonth(parseInt(e.target.value))}
                className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl px-4 py-2.5 text-sm dark:text-neutral-200 focus:outline-none focus:ring-2 focus:ring-brand/20"
              >
                {['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'].map((m, i) => (
                  <option key={i} value={i} className="dark:bg-neutral-900">{m}</option>
                ))}
              </select>
            </div>
          </div>

          <div className={`space-y-1 p-4 rounded-2xl border-2 transition-all ${
            isBirthdayMonth ? 'bg-orange-50 dark:bg-orange-900/10 border-orange-200 dark:border-orange-800' : 'bg-neutral-50 dark:bg-neutral-900/50 border-transparent'
          }`}>
            <label className="text-xs font-bold text-brand dark:text-brand uppercase tracking-wider flex items-center gap-2 mb-2">
              <Cake className="w-3 h-3" /> Sabor do Bolo Desejado
            </label>
            <input 
              type="text" 
              value={cakeFlavor}
              onChange={(e) => setCakeFlavor(e.target.value)}
              className="w-full bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl px-4 py-2.5 text-sm dark:text-neutral-200 focus:outline-none focus:ring-2 focus:ring-brand/20 transition-all"
              placeholder="Ex: Chocolate Trufado, Morango..."
              disabled={!isBirthdayMonth && profile.cakeFlavor === ''}
            />
            {!isBirthdayMonth && (
              <p className="text-[10px] text-neutral-400 dark:text-neutral-500 mt-2 italic px-1">
                * Editável apenas no seu mês de aniversário ou para salvar preferência.
              </p>
            )}
          </div>

          <button 
            onClick={handleSave}
            disabled={saving}
            className="w-full btn-primary h-12 shadow-lg shadow-brand/20 mt-4"
          >
            {saving ? <div className="w-5 h-5 border-2 border-white/30 border-t-white animate-spin rounded-full" /> : <><Save className="w-5 h-5" /> Salvar Alterações</>}
          </button>
        </div>
      </div>
    </div>
  );
}
