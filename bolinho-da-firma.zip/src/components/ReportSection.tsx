import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, doc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Contribution, UserProfile } from '../types';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Check, X, FileText, Download, Users, TrendingUp, AlertCircle } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../lib/error-handler';

export default function ReportSection() {
  const [contributions, setContributions] = useState<Contribution[]>([]);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);

  useEffect(() => {
    const qUsers = query(collection(db, 'users'));
    const unsubUsers = onSnapshot(qUsers, (snap) => {
      setAllUsers(snap.docs.map(d => d.data() as UserProfile));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'users');
    });

    const q = query(
      collection(db, 'contributions'), 
      where('month', '==', selectedMonth),
      where('year', '==', selectedYear)
    );
    const unsub = onSnapshot(q, (snapshot) => {
      setContributions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }) as Contribution));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'contributions');
    });
    return () => { unsub(); unsubUsers(); };
  }, [selectedMonth, selectedYear]);

  const updateStatus = async (id: string, status: 'approved' | 'rejected') => {
    try {
      await updateDoc(doc(db, 'contributions', id), { status }).catch(err => {
        handleFirestoreError(err, OperationType.UPDATE, `contributions/${id}`);
        throw err;
      });
    } catch (e) {
      if (!(e instanceof Error && e.message.startsWith('{"error"'))) {
        alert('Erro ao atualizar status');
      }
    }
  };

  const approvedContributions = contributions.filter(c => c.status === 'approved');
  const totalAmount = approvedContributions.reduce((acc, c) => acc + c.amount, 0);
  const totalPending = contributions.filter(c => c.status === 'pending').length;
  const awaitingCount = Math.max(0, allUsers.length - approvedContributions.length);
  const awaitingUsers = allUsers.filter(user => 
    !contributions.some(c => c.userId === user.uid && c.status === 'approved')
  ).sort((a, b) => a.name.localeCompare(b.name));
  
  const months = Array.from({ length: 12 }, (_, i) => ({
    value: i,
    label: format(new Date(2024, i, 1), 'MMMM', { locale: ptBR })
  }));

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-neutral-800 p-6 rounded-3xl border border-neutral-100 dark:border-neutral-700 shadow-sm transition-colors duration-300">
          <div className="w-8 h-8 rounded-lg bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-500 flex items-center justify-center mb-4">
            <TrendingUp className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">Arrecadado</p>
          <p className="text-3xl font-display font-bold text-neutral-800 dark:text-neutral-100">R$ {totalAmount.toFixed(2)}</p>
        </div>
        <div className="bg-white dark:bg-neutral-800 p-6 rounded-3xl border border-neutral-100 dark:border-neutral-700 shadow-sm transition-colors duration-300">
          <div className="w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-500 flex items-center justify-center mb-4">
            <Users className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">Participantes</p>
          <p className="text-3xl font-display font-bold text-neutral-800 dark:text-neutral-100">{contributions.length}/{allUsers.length}</p>
        </div>
        <div className="bg-white dark:bg-neutral-800 p-6 rounded-3xl border border-neutral-100 dark:border-neutral-700 shadow-sm transition-colors duration-300">
          <div className="w-8 h-8 rounded-lg bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-500 flex items-center justify-center mb-4">
            <Check className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">Pendentes</p>
          <p className="text-3xl font-display font-bold text-neutral-800 dark:text-neutral-100">{totalPending}</p>
        </div>
        <div className="bg-white dark:bg-neutral-800 p-6 rounded-3xl border border-neutral-100 dark:border-neutral-700 shadow-sm transition-colors duration-300">
          <div className="w-8 h-8 rounded-lg bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-500 flex items-center justify-center mb-4">
            <AlertCircle className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">Aguardando contribuição</p>
          <p className="text-3xl font-display font-bold text-neutral-800 dark:text-neutral-100">{awaitingCount}</p>
        </div>
      </div>

      <div className="bg-white dark:bg-neutral-800 rounded-3xl shadow-sm border border-neutral-100 dark:border-neutral-700 p-6 overflow-hidden transition-colors duration-300">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-display font-bold text-neutral-800 dark:text-neutral-100">Relatório Mensal</h2>
          <div className="flex gap-2">
            <select 
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
              className="bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl px-3 py-1.5 text-xs dark:text-neutral-200 font-bold focus:outline-none"
            >
              {months.map(m => <option key={m.value} value={m.value} className="dark:bg-neutral-900">{m.label}</option>)}
            </select>
            <select 
              value={selectedYear}
              onChange={(e) => setSelectedYear(parseInt(e.target.value))}
              className="bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl px-3 py-1.5 text-xs dark:text-neutral-200 font-bold focus:outline-none"
            >
              {[2025, 2026, 2027].map(y => <option key={y} value={y} className="dark:bg-neutral-900">{y}</option>)}
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-neutral-100 dark:border-neutral-700 italic">
                <th className="py-4 text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">Colaborador</th>
                <th className="py-4 text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">Valor</th>
                <th className="py-4 text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">Data</th>
                <th className="py-4 text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">Status</th>
                <th className="py-4 text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-50 dark:divide-neutral-700 font-sans">
              {contributions.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-neutral-400 dark:text-neutral-600 italic">Nenhuma contribuição este mês.</td>
                </tr>
              ) : (
                contributions.map(c => (
                  <tr key={c.id} className="group hover:bg-neutral-50/50 dark:hover:bg-neutral-900/50 transition-colors">
                    <td className="py-4">
                      <div className="flex items-center gap-3">
                        <img src={c.userPhoto || `https://api.dicebear.com/7.x/avataaars/svg?seed=${c.userName}`} className="w-8 h-8 rounded-full shadow-sm border border-neutral-100 dark:border-neutral-700" />
                        <span className="text-sm font-bold text-neutral-800 dark:text-neutral-200">{c.userName}</span>
                      </div>
                    </td>
                    <td className="py-4 text-sm font-bold text-neutral-700 dark:text-neutral-300">
                      R$ {c.amount.toFixed(2)}
                    </td>
                    <td className="py-4 text-[10px] text-neutral-400 dark:text-neutral-500 font-bold uppercase">
                      {format(c.timestamp?.toDate() || new Date(), 'dd/MM HH:mm')}
                    </td>
                    <td className="py-4">
                      <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-full ${
                        c.status === 'approved' ? 'bg-green-100 dark:bg-green-900/20 text-green-700 dark:text-green-500' :
                        c.status === 'rejected' ? 'bg-red-100 dark:bg-red-900/20 text-red-700 dark:text-red-500' :
                        'bg-amber-100 dark:bg-amber-900/20 text-amber-700 dark:text-amber-500'
                      }`}>
                        {c.status === 'approved' ? 'Confirmado' :
                         c.status === 'rejected' ? 'Recusado' : 'Pendente'}
                      </span>
                    </td>
                    <td className="py-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        {c.status === 'pending' ? (
                          <>
                            <button 
                              onClick={() => updateStatus(c.id!, 'approved')} 
                              className="p-2 hover:bg-green-100 dark:hover:bg-green-900/40 text-green-600 dark:text-green-500 rounded-xl transition-all active:scale-90"
                              title="Aprovar"
                            >
                              <Check className="w-5 h-5" />
                            </button>
                            <button 
                              onClick={() => updateStatus(c.id!, 'rejected')} 
                              className="p-2 hover:bg-red-100 dark:hover:bg-red-900/40 text-red-600 dark:text-red-500 rounded-xl transition-all active:scale-90"
                              title="Recusar"
                            >
                              <X className="w-5 h-5" />
                            </button>
                          </>
                        ) : (
                          <div className={`p-2 rounded-xl ${c.status === 'approved' ? 'text-green-500' : 'text-red-500'}`}>
                            {c.status === 'approved' ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}
                          </div>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {awaitingUsers.length > 0 && (
        <div className="bg-white dark:bg-neutral-800 rounded-3xl shadow-sm border border-neutral-100 dark:border-neutral-700 p-6 transition-colors duration-300">
          <div className="flex items-center gap-2 mb-6">
            <div className="w-8 h-8 rounded-lg bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-500 flex items-center justify-center">
              <AlertCircle className="w-5 h-5" />
            </div>
            <h2 className="text-xl font-display font-bold text-neutral-800 dark:text-neutral-100">Aguardando contribuição</h2>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {awaitingUsers.map(user => (
              <div key={user.uid} className="flex items-center gap-3 p-3 bg-neutral-50 dark:bg-neutral-900/50 rounded-2xl border border-neutral-100 dark:border-neutral-700">
                <img 
                  src={user.photoUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.name}`} 
                  className="w-10 h-10 rounded-full shadow-sm bg-white dark:bg-neutral-800 border-2 border-white dark:border-neutral-700" 
                  alt={user.name}
                />
                <div>
                  <p className="text-sm font-bold text-neutral-800 dark:text-neutral-200 line-clamp-1">{user.name}</p>
                  <p className="text-[10px] text-neutral-400 dark:text-neutral-500 font-bold uppercase">Sem confirmação</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
