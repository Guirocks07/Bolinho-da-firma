import React from 'react';
import { Sun, Moon } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { motion } from 'motion/react';

export default function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();

  return (
    <button
      onClick={toggleTheme}
      className="relative flex items-center justify-between w-14 h-7 p-1 rounded-full bg-neutral-200 dark:bg-neutral-700 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-brand"
      aria-label="Alternar tema"
    >
      <motion.div
        animate={{ x: theme === 'light' ? 0 : 28 }}
        transition={{ type: 'spring', stiffness: 500, damping: 30 }}
        className="absolute w-5 h-5 rounded-full bg-white dark:bg-neutral-900 shadow-sm flex items-center justify-center z-10"
      >
        {theme === 'light' ? (
          <Sun className="w-3.5 h-3.5 text-amber-500" />
        ) : (
          <Moon className="w-3.5 h-3.5 text-brand" />
        )}
      </motion.div>
      <Sun className="w-4 h-4 ml-1 text-neutral-400" />
      <Moon className="w-4 h-4 mr-1 text-neutral-400" />
    </button>
  );
}
