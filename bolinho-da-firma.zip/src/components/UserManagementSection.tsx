import React, { useState, useEffect } from 'react';
import { collection, query, onSnapshot, doc, deleteDoc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { UserProfile } from '../types';
import { UserX, Users, Search, Mail, Shield, ShieldAlert, UserMinus, UserPlus } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../lib/error-handler';
import { useAuth } from '../contexts/AuthContext';

export default function UserManagementSection() {
  const { profile } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const isMaster = profile?.role === 'master' || profile?.email?.toLowerCase() === 'guirocks2016@gmail.com';

  useEffect(() => {
    const q = query(collection(db, 'users'));
    const unsubscribe = onSnapshot(q, (snap) => {
      setUsers(snap.docs.map(d => d.data() as UserProfile).sort((a, b) => a.name.localeCompare(b.name)));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'users');
    });
    return () => unsubscribe();
  }, []);

  const handleDeleteUser = async (userId: string, targetRole: string, userEmail: string) => {
    if (targetRole === 'master' || userEmail === 'guirocks2016@gmail.com') {
      alert('O administrador mestre não pode ser removido.');
      return;
    }

    if (!window.confirm(`Tem certeza que deseja remover o usuário ${userEmail}? Esta ação não pode ser desfeita.`)) {
      return;
    }

    setDeletingId(userId);
    try {
      await deleteDoc(doc(db, 'users', userId)).catch(err => {
        handleFirestoreError(err, OperationType.DELETE, `users/${userId}`);
        throw err;
      });
      alert('Usuário removido com sucesso.');
    } catch (error) {
      console.error('Erro ao deletar usuário:', error);
      alert('Erro ao remover usuário. Verifique as permissões.');
    } finally {
      setDeletingId(null);
    }
  };

  const handleToggleAdmin = async (targetUser: UserProfile) => {
    if (!profile || (profile.role !== 'master' && profile.email?.toLowerCase() !== "guirocks2016@gmail.com")) {
      alert("Apenas o usuário mestre pode alterar permissões.");
      return;
    }

    if (!targetUser.uid) {
      alert("ID do usuário não encontrado.");
      return;
    }

    if (targetUser.role === 'master' || targetUser.email?.toLowerCase() === "guirocks2016@gmail.com") {
      alert("O usuário master não pode ter sua função alterada.");
      return;
    }

    const newRole = targetUser.role === "admin" ? "user" : "admin";

    try {
      setUpdatingId(targetUser.uid);
      await updateDoc(doc(db, "users", targetUser.uid), {
        role: newRole
      }).catch(err => {
        handleFirestoreError(err, OperationType.UPDATE, `users/${targetUser.uid}`);
        throw err;
      });
      alert(newRole === "admin" ? "Usuário promovido a administrador." : "Administrador removido.");
    } catch (error: any) {
      console.error("Erro ao alterar função do usuário:", error);
      alert("Erro ao alterar função do usuário: " + (error.message || String(error)));
    } finally {
      setUpdatingId(null);
    }
  };

  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-neutral-800 p-6 rounded-3xl border border-neutral-100 dark:border-neutral-700 shadow-sm transition-colors duration-300">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-brand/10 text-brand flex items-center justify-center">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-display font-bold text-neutral-800 dark:text-neutral-100">Gerenciamento de Usuários</h2>
              <p className="text-xs text-neutral-400 dark:text-neutral-500 font-bold uppercase tracking-wider">{users.length} usuários registrados</p>
            </div>
          </div>
          
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400 dark:text-neutral-500" />
            <input 
              type="text"
              placeholder="Buscar por nome ou e-mail..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl text-sm dark:text-neutral-200 focus:outline-none focus:ring-2 focus:ring-brand/20 w-full md:w-64"
            />
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-neutral-800 rounded-3xl shadow-sm border border-neutral-100 dark:border-neutral-700 overflow-hidden transition-colors duration-300">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-neutral-100 dark:border-neutral-700 bg-neutral-50/50 dark:bg-neutral-900/50">
                <th className="px-6 py-4 text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">Usuário</th>
                <th className="px-6 py-4 text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">E-mail</th>
                <th className="px-6 py-4 text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider text-center">Função</th>
                <th className="px-6 py-4 text-xs font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-50 dark:divide-neutral-700">
              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-6 py-12 text-center text-neutral-400 dark:text-neutral-600 italic">
                    Nenhum usuário encontrado.
                  </td>
                </tr>
              ) : (
                filteredUsers.map(user => (
                  <tr key={user.uid} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-900/50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <img 
                          src={user.photoUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.name}`} 
                          className="w-10 h-10 rounded-full shadow-sm border border-neutral-100 dark:border-neutral-700" 
                          alt={user.name}
                        />
                        <span className="text-sm font-bold text-neutral-800 dark:text-neutral-100">{user.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 text-sm text-neutral-500 dark:text-neutral-400">
                        <Mail className="w-3 h-3" />
                        {user.email}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex justify-center">
                        {user.role === 'master' || user.email === 'guirocks2016@gmail.com' ? (
                          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-500 text-[10px] font-bold uppercase ring-1 ring-amber-200 dark:ring-amber-800">
                            <ShieldAlert className="w-3 h-3" />
                            MASTER
                          </div>
                        ) : user.role === 'admin' ? (
                          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-brand/10 text-brand text-[10px] font-bold uppercase ring-1 ring-brand/20 dark:ring-brand/30">
                            <Shield className="w-3 h-3" />
                            ADMIN
                          </div>
                        ) : (
                          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-neutral-100 dark:bg-neutral-700 text-neutral-500 dark:text-neutral-400 text-[10px] font-bold uppercase ring-1 ring-neutral-200 dark:ring-neutral-600">
                            USUÁRIO
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-end gap-2">
                        {isMaster && user.role !== 'master' && user.email !== 'guirocks2016@gmail.com' && (
                          <button
                            onClick={() => handleToggleAdmin(user)}
                            disabled={updatingId === user.uid}
                            className={`p-2 rounded-xl transition-all active:scale-90 disabled:opacity-50 ${
                              user.role === 'admin' 
                                ? 'text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-900/20' 
                                : 'text-brand hover:bg-brand/5 dark:hover:bg-brand/20'
                            }`}
                            title={user.role === 'admin' ? "Remover Admin" : "Tornar Admin"}
                          >
                            {user.role === 'admin' ? <UserMinus className="w-5 h-5" /> : <UserPlus className="w-5 h-5" />}
                          </button>
                        )}

                        {user.role !== 'master' && user.email !== 'guirocks2016@gmail.com' ? (
                          <button
                            onClick={() => handleDeleteUser(user.uid, user.role, user.email)}
                            disabled={deletingId === user.uid}
                            className="p-2 text-neutral-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-all active:scale-90 disabled:opacity-50"
                            title="Remover Usuário"
                          >
                            <UserX className="w-5 h-5" />
                          </button>
                        ) : (
                          <span className="text-[10px] text-neutral-300 dark:text-neutral-600 font-bold uppercase px-2 py-2">Imutável</span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
